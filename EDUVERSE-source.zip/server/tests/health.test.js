import assert from 'node:assert/strict';
import test from 'node:test';

const appModule = await import('../app.js').catch(() => ({}));

test('server module exposes an injectable Express application factory', () => {
  assert.equal(typeof appModule.createApp, 'function');
});

