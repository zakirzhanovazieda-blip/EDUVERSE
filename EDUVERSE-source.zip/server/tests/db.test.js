import assert from 'node:assert/strict';
import test from 'node:test';

const databaseModule = await import('../db/index.js').catch(() => ({}));

test('database module exposes the shared adapter factory', () => {
  assert.equal(typeof databaseModule.createDatabase, 'function');
});

