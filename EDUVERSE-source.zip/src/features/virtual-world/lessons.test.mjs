import test from 'node:test';
import assert from 'node:assert/strict';
import { buildings } from './buildings.js';
import { getLessonByBuildingId, lessonCatalog } from './lessons.js';

test('each learning world has a complete, valid ten-question lesson', () => {
  assert.equal(Object.keys(lessonCatalog).length, buildings.length);
  for (const building of buildings) {
    const lesson = getLessonByBuildingId(building.id);
    assert.ok(lesson?.introduction, `${building.id} should include an introduction`);
    assert.equal(lesson.questions.length, 10, `${building.id} should include ten questions`);
    assert.ok(new Set(lesson.questions.map((item) => item.answer)).size > 1, `${building.id} answer positions should vary`);
    for (const [index, item] of lesson.questions.entries()) {
      assert.ok(item.prompt, `${building.id} question ${index + 1} needs a prompt`);
      assert.equal(item.options.length, 3);
      assert.ok(item.answer >= 0 && item.answer < item.options.length);
      assert.ok(item.explanation, `${building.id} question ${index + 1} needs feedback`);
    }
  }
});
