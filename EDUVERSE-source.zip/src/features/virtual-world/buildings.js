export const buildings = [
  {
    id: 'computer-world',
    title: 'Computer World',
    shortTitle: 'Компьютер әлемі',
    description: 'Компьютердің құрылысын зерттеп, цифрлық әлемнің негізімен таныс.',
    model: 'computer',
    position: [-3.8, 0, -1.2],
    color: '#65caff',
  },
  {
    id: 'algorithm-city',
    title: 'Algorithm City',
    shortTitle: 'Алгоритмдер қаласы',
    description: 'Логикалық ойлау мен алгоритм құруды қызықты тапсырмалар арқылы меңгер.',
    model: 'algorithm',
    position: [-1.6, 0, -2.7],
    color: '#a995ff',
  },
  {
    id: 'python-lab',
    title: 'Python Laboratory',
    shortTitle: 'Python зертханасы',
    description: 'Алғашқы бағдарламаңды жазып, Python арқылы идеяларыңды іске асыр.',
    model: 'python',
    position: [0.6, 0, -2.65],
    color: '#79e4c1',
  },
  {
    id: 'network-world',
    title: 'Network World',
    shortTitle: 'Желі әлемі',
    description: 'Интернеттің қалай жұмыс істейтінін және құрылғылардың байланысын біл.',
    model: 'network',
    position: [3.55, 0, -1.25],
    color: '#73a9ff',
  },
  {
    id: 'cyber-security',
    title: 'Cyber Security',
    shortTitle: 'Киберқауіпсіздік',
    description: 'Құпиясөздер мен деректерді қорғап, желідегі қауіпсіздікті үйрен.',
    model: 'security',
    position: [3.7, 0, 1.85],
    color: '#f29ce1',
  },
  {
    id: 'ai-laboratory',
    title: 'AI Laboratory',
    shortTitle: 'ЖИ зертханасы',
    description: 'Жасанды интеллектпен танысып, оның заманауи мүмкіндіктерін аш.',
    model: 'ai',
    position: [0.8, 0, 2.75],
    color: '#d69cff',
  },
];

export function getBuildingById(id) {
  return buildings.find((building) => building.id === id);
}
