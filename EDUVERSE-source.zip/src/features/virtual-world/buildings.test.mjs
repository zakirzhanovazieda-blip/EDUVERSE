import test from 'node:test';
import assert from 'node:assert/strict';
import { buildings, getBuildingById } from './buildings.js';

test('virtual world exposes six distinct learning buildings', () => {
  assert.equal(buildings.length, 6);
  assert.equal(new Set(buildings.map(({ id }) => id)).size, 6);
  assert.ok(buildings.every(({ title, description, position, model }) =>
    title && description && position.length === 3 && model));
});

test('building selection lookup returns a place by id', () => {
  assert.equal(getBuildingById('python-lab'), buildings.find(({ id }) => id === 'python-lab'));
  assert.equal(getBuildingById('missing-place'), undefined);
});
