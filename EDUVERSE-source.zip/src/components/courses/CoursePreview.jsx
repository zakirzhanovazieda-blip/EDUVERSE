import { motion } from 'framer-motion';
import { ArrowUpRight, BrainCircuit, Code2, Network, ShieldCheck, Terminal } from 'lucide-react';

const courses = [
  { number: '01', buildingId: 'computer-world', title: 'Компьютер әлемі', description: 'Компьютер құрылғылары мен цифрлық дүниенің негізін таны.', icon: Terminal, color: 'violet' },
  { number: '02', buildingId: 'algorithm-city', title: 'Алгоритмдер қаласы', description: 'Логикалық ойлауды дамытып, тапсырмаларды қадаммен шеш.', icon: Code2, color: 'cyan' },
  { number: '03', buildingId: 'python-lab', title: 'Python зертханасы', description: 'Алғашқы кодыңды жазып, өз идеяңды іске асыр.', icon: BrainCircuit, color: 'blue' },
  { number: '04', buildingId: 'cyber-security', title: 'Киберқауіпсіздік', description: 'Желіде қауіпсіз жүріп, деректеріңді қорғауды үйрен.', icon: ShieldCheck, color: 'pink' },
];

export default function CoursePreview() {
  return (
    <section className="courses-section" id="courses">
      <div className="section-heading">
        <div><p className="section-kicker">ЗЕРТТЕУГЕ ДАЙЫНСЫҢ БА?</p><h2>Білімге апарар <span>жолдар</span></h2></div>
        <a className="all-courses-link" href="#world">Аралдағы бағыттар <ArrowUpRight size={16} aria-hidden="true" /></a>
      </div>
      <div className="course-grid">
        {courses.map(({ number, buildingId, title, description, icon: Icon, color }, index) => (
          <motion.a
            className="course-card"
            href="#world"
            onClick={() => window.dispatchEvent(new CustomEvent('eduverse:select-building', { detail: buildingId }))}
            key={number}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.45, delay: index * 0.08 }}
            whileHover={{ y: -5 }}
          >
            <div className={`course-icon ${color}`}><Icon size={21} strokeWidth={1.8} aria-hidden="true" /></div>
            <span className="course-number">БАҒЫТ {number}</span>
            <h3>{title}</h3>
            <p>{description}</p>
            <span className="course-meta">10 сұрақ <i /> 5 минут</span>
            <span className="course-arrow" aria-label="Бағыт туралы">↗</span>
          </motion.a>
        ))}
      </div>
    </section>
  );
}
