import { lazy, Suspense } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const VirtualWorld = lazy(() => import('../virtual-world/VirtualWorld.jsx'));

export default function HeroSection() {
  return (
    <section className="hero" id="home">
      <motion.div
        className="hero-copy"
        initial={{ opacity: 0, y: 22 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.65, ease: 'easeOut' }}
      >
        <div className="hero-label"><span className="label-pulse" /> БІЛІМНІҢ ЖАҢА ӨЛШЕМІ</div>
        <h1>Білімнің жаңа<br />әлеміне <span>қош келдің!</span></h1>
        <p className="hero-description">Үйрен. Зертте. Тәжірибе жаса. Болашағыңды EDUVERSE-пен құр!</p>
        <div className="hero-actions">
          <a className="primary-button" href="#world">
            Виртуалды әлемге саяхат <ArrowRight size={18} aria-hidden="true" />
          </a>
          <a className="secondary-button" href="#courses">Курстарды көру</a>
        </div>
        <div className="hero-trust"><span className="trust-avatars" aria-hidden="true"><i>Ә</i><i>А</i><i>Н</i></span><span><strong>Жаңа буынға арналған</strong><br />информатика платформасы</span></div>
      </motion.div>
      <Suspense fallback={<div className="universe-art virtual-world scene-loading" id="world"><div className="scene-loading-content"><span className="loading-orbit" /><span>EDUVERSE аралы жүктелуде…</span></div></div>}>
        <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, ease: 'easeOut' }}>
          <VirtualWorld />
        </motion.div>
      </Suspense>
    </section>
  );
}
