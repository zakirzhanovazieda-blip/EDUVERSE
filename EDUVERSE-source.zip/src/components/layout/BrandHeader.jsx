import { useEffect, useState } from 'react';
import { Menu, Orbit, X } from 'lucide-react';

const links = [
  { href: '#home', label: 'Басты бет' },
  { href: '#world', label: 'Виртуалды әлем' },
  { href: '#courses', label: 'Курстар' },
  { href: '#about', label: 'Біз туралы' },
];

export default function BrandHeader() {
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    if (!menuOpen) return undefined;
    const closeOnEscape = (event) => { if (event.key === 'Escape') setMenuOpen(false); };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [menuOpen]);

  return (
    <header className="site-header">
      <a className="brand" href="#home" aria-label="EDUVERSE басты беті">
        <span className="brand-symbol"><Orbit size={22} strokeWidth={2.3} aria-hidden="true" /></span>
        <span className="brand-name">EDU<span>VERSE</span></span>
      </a>

      <button
        className="menu-toggle"
        type="button"
        aria-label={menuOpen ? 'Мәзірді жабу' : 'Мәзірді ашу'}
        aria-expanded={menuOpen}
        aria-controls="main-nav"
        onClick={() => setMenuOpen((open) => !open)}
      >
        {menuOpen ? <X size={22} /> : <Menu size={22} />}
      </button>

      <nav id="main-nav" className={`main-nav${menuOpen ? ' is-open' : ''}`} aria-label="Негізгі мәзір">
        {links.map((link) => (
          <a key={link.href} href={link.href} onClick={() => setMenuOpen(false)}>{link.label}</a>
        ))}
        <a className="login-button mobile-login" href="#login" onClick={() => setMenuOpen(false)}>Кіру</a>
      </nav>

      <a className="login-button desktop-login" href="#login">Кіру</a>
    </header>
  );
}
