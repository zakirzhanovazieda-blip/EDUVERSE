import { useEffect, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowRight, Compass, Move3d, X, ZoomIn } from 'lucide-react';
import { buildings, getBuildingById } from '../../features/virtual-world/buildings.js';
import { getLessonByBuildingId } from '../../features/virtual-world/lessons.js';
import IslandScene from './IslandScene.jsx';

export default function VirtualWorld() {
  const [selectedId, setSelectedId] = useState(null);
  const [enteredBuilding, setEnteredBuilding] = useState(null);
  const selectedBuilding = getBuildingById(selectedId);

  useEffect(() => {
    const selectBuilding = (event) => {
      setSelectedId(event.detail);
      setEnteredBuilding(null);
    };
    window.addEventListener('eduverse:select-building', selectBuilding);
    return () => window.removeEventListener('eduverse:select-building', selectBuilding);
  }, []);

  return (
    <div className="universe-art virtual-world" id="world">
      <div className={`island-stage${enteredBuilding ? ' has-entry' : ''}`} aria-label="Басқаруға болатын EDUVERSE виртуалды аралы">
        <Canvas
          shadows
          dpr={[1, 1.35]}
          camera={{ position: [12, 10, 15], fov: 38, near: 0.1, far: 100 }}
          gl={{ antialias: true, alpha: false, powerPreference: 'high-performance' }}
          onPointerMissed={() => setSelectedId(null)}
          fallback={<div className="scene-fallback">3D көрініс бұл құрылғыда ашылмады.</div>}
        >
          <IslandScene selectedBuilding={selectedBuilding} onSelect={(building) => setSelectedId(building.id)} />
        </Canvas>

        <div className="scene-topline" aria-hidden="true">
          <span><i /> EDUVERSE АРАЛЫ</span>
          <span className="scene-live"><b /> ИНТЕРАКТИВТІ</span>
        </div>

        <div className="scene-camera-hint" aria-hidden="true">
          <span><Move3d size={13} /> Айналдыру</span>
          <span><ZoomIn size={13} /> Жақындату</span>
        </div>

        <AnimatePresence mode="wait">
          {selectedBuilding ? (
            <motion.section
              className="island-detail-card"
              key={selectedBuilding.id}
              initial={{ opacity: 0, x: -12, y: 8 }}
              animate={{ opacity: 1, x: 0, y: 0 }}
              exit={{ opacity: 0, x: -8, y: 4 }}
              transition={{ duration: 0.22 }}
              aria-live="polite"
            >
              <button className="detail-close" type="button" aria-label="Таңдауды жабу" onClick={() => setSelectedId(null)}><X size={14} /></button>
              <span className="detail-eyebrow"><i style={{ backgroundColor: selectedBuilding.color }} /> ОҚУ ӘЛЕМІ</span>
              <h2>{selectedBuilding.shortTitle}</h2>
              <p>{selectedBuilding.description}</p>
              <button className="enter-building" type="button" onClick={() => setEnteredBuilding(selectedBuilding)}>
                Сабақты бастау <ArrowRight size={15} aria-hidden="true" />
              </button>
            </motion.section>
          ) : (
            <motion.div
              className="island-discovery-hint"
              key="discovery"
              initial={{ opacity: 0, y: 7 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 7 }}
            >
              <Compass size={15} aria-hidden="true" /> <span>Ғимаратты таңдап, білім әлемін зертте</span>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {enteredBuilding && (
            <motion.div className="building-entry-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <motion.section className="building-entry-card" role="dialog" aria-modal="true" aria-labelledby="entry-title" initial={{ opacity: 0, scale: 0.94, y: 12 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.96 }}>
                <LessonExperience building={enteredBuilding} onClose={() => setEnteredBuilding(null)} />
              </motion.section>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="building-quick-select" aria-label="Оқу ғимаратын таңдау">
        {buildings.map((building) => (
          <button
            key={building.id}
            className={selectedId === building.id ? 'quick-building is-active' : 'quick-building'}
            type="button"
            onClick={() => setSelectedId(building.id)}
            aria-pressed={selectedId === building.id}
            title={building.title}
          >
            <i style={{ background: building.color }} />
            <span>{building.shortTitle.replace(' зертханасы', '').replace(' әлемі', '').replace(' қаласы', '').replace('Киберқауіпсіздік', 'Қауіпсіздік')}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function LessonExperience({ building, onClose }) {
  const lesson = getLessonByBuildingId(building.id) ?? getLessonByBuildingId('computer-world');
  const lessonQuestions = lesson.questions;
  const [stage, setStage] = useState('intro');
  const [step, setStep] = useState(0);
  const [choice, setChoice] = useState(null);
  const [answers, setAnswers] = useState([]);
  const finished = step >= lessonQuestions.length;
  const question = lessonQuestions[step];
  const correct = choice === question?.answer;

  useEffect(() => {
    const closeOnEscape = (event) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [onClose]);

  function submitAnswer() {
    if (choice === null) return;
    setAnswers((current) => [...current, choice === question.answer]);
    setChoice(null);
    setStep((current) => current + 1);
  }

  return <div className="lesson-content">
    <p className="detail-eyebrow">{building.shortTitle.toLocaleUpperCase('kk-KZ')} · 1-САБАҚ</p>
    {stage === 'intro' ? <>
      <span className="entry-orbit"><Compass size={24} aria-hidden="true" /></span>
      <h2 id="entry-title">{building.shortTitle}</h2>
      <p className="lesson-introduction">{lesson.introduction}</p>
      <div className="lesson-meta"><span>10 сұрақ</span><span>5 минут</span></div>
      <button className="enter-building" type="button" onClick={() => setStage('quiz')}>Түсіндім, тестті бастау <ArrowRight size={15} aria-hidden="true" /></button>
      <button className="lesson-back" type="button" onClick={onClose}>Аралға оралу</button>
    </> : finished ? <>
      <span className="entry-orbit"><Compass size={24} aria-hidden="true" /></span>
      <h2 id="entry-title">Сабақ аяқталды!</h2>
      <p>Дұрыс жауап: {answers.filter(Boolean).length} / {lessonQuestions.length}. {building.shortTitle} сабағын аяқтадың.</p>
      <button className="enter-building" type="button" onClick={onClose}>Аралға оралу <ArrowRight size={15} aria-hidden="true" /></button>
      <button className="lesson-back" type="button" onClick={() => { setStep(0); setChoice(null); setAnswers([]); setStage('intro'); }}>Қайта оқу</button>
    </> : <>
      <div className="lesson-progress"><span style={{ width: `${(step / lessonQuestions.length) * 100}%` }} /></div>
      <p className="lesson-step">СҰРАҚ {step + 1} / {lessonQuestions.length}</p>
      <h2 id="entry-title">{question.prompt}</h2>
      <div className="lesson-options" role="group" aria-label="Жауап нұсқалары">
        {question.options.map((option, index) => <button key={option} className={choice === index ? 'lesson-option is-selected' : 'lesson-option'} type="button" onClick={() => setChoice(index)} aria-pressed={choice === index}>{option}</button>)}
      </div>
      {choice !== null && <p className={correct ? 'lesson-feedback is-correct' : 'lesson-feedback'} role="status">{correct ? 'Дұрыс! ' : 'Бұл жолы дұрыс болмады. '}{question.explanation}</p>}
      <button className="enter-building" type="button" disabled={choice === null} onClick={submitAnswer}>{choice === null ? 'Жауапты таңда' : 'Келесі сұрақ'} <ArrowRight size={15} aria-hidden="true" /></button>
    </>}
  </div>;
}
