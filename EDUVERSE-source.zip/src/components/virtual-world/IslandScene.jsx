import { useMemo, useRef, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import {
  AdaptiveDpr,
  ContactShadows,
  Float,
  Html,
  OrbitControls,
  Sparkles,
} from '@react-three/drei';
import {
  BackSide,
  CatmullRomCurve3,
  ExtrudeGeometry,
  Shape,
  ShapeGeometry,
  Vector3,
} from 'three';
import { buildings } from '../../features/virtual-world/buildings.js';

const islandOutline = new Shape();
const outlinePoints = 14;
for (let index = 0; index < outlinePoints; index += 1) {
  const angle = (index / outlinePoints) * Math.PI * 2;
  const variation = 1 + Math.sin(angle * 3) * 0.055 + Math.cos(angle * 5) * 0.035;
  const x = Math.cos(angle) * 6.4 * variation;
  const z = Math.sin(angle) * 4.9 * variation;
  if (index === 0) islandOutline.moveTo(x, z);
  else islandOutline.lineTo(x, z);
}
islandOutline.closePath();

function MainIsland() {
  const topGeometry = useMemo(() => new ShapeGeometry(islandOutline, 12), []);
  const rockGeometry = useMemo(() => new ExtrudeGeometry(islandOutline, {
    depth: 2.15,
    bevelEnabled: true,
    bevelSegments: 2,
    steps: 1,
    bevelSize: 0.18,
    bevelThickness: 0.18,
    curveSegments: 2,
  }), []);

  return (
    <group>
      <mesh geometry={rockGeometry} rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.15, 0]} castShadow receiveShadow>
        <meshStandardMaterial color="#454267" roughness={0.88} flatShading />
      </mesh>
      <mesh geometry={topGeometry} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.015, 0]} receiveShadow>
        <meshStandardMaterial color="#4c8c7a" roughness={0.92} side={2} />
      </mesh>
      <mesh position={[0, -1.85, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[3.15, 8]} />
        <meshStandardMaterial color="#373954" roughness={0.9} flatShading />
      </mesh>
    </group>
  );
}

function IslandSky() {
  return (
    <mesh scale={100} renderOrder={-1000}>
      <sphereGeometry args={[1, 32, 20]} />
      <shaderMaterial
        side={BackSide}
        depthWrite={false}
        toneMapped={false}
        vertexShader={`varying vec3 vSkyDirection; void main() { vSkyDirection = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`}
        fragmentShader={`varying vec3 vSkyDirection; void main() { float height = normalize(vSkyDirection).y; vec3 horizon = vec3(0.72, 0.88, 0.98); vec3 middle = vec3(0.31, 0.65, 0.91); vec3 zenith = vec3(0.10, 0.34, 0.69); vec3 sky = mix(horizon, middle, smoothstep(-0.18, 0.38, height)); sky = mix(sky, zenith, smoothstep(0.38, 0.98, height)); gl_FragColor = vec4(sky, 1.0); }`}
      />
    </mesh>
  );
}

function IslandPath() {
  const curve = useMemo(() => new CatmullRomCurve3([
    new Vector3(-4.15, 0.045, 0.9),
    new Vector3(-2.7, 0.045, 1.55),
    new Vector3(-0.7, 0.045, 1.8),
    new Vector3(1.55, 0.045, 1.45),
    new Vector3(3.9, 0.045, 0.45),
  ]), []);

  return (
    <mesh>
      <tubeGeometry args={[curve, 48, 0.095, 6, false]} />
      <meshStandardMaterial color="#c4b68a" roughness={0.96} />
    </mesh>
  );
}

function TerrainDetails() {
  return (
    <group>
      <mesh position={[-4.5, 0.02, 2.15]} scale={[1.25, 0.13, 0.68]} rotation={[0, -0.35, 0]}>
        <dodecahedronGeometry args={[1, 0]} />
        <meshStandardMaterial color="#578d7d" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[4.45, 0.015, 2.75]} scale={[1.2, 0.14, 0.58]} rotation={[0, 0.24, 0]}>
        <dodecahedronGeometry args={[1, 0]} />
        <meshStandardMaterial color="#598b79" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[-5.05, 0.02, -2.15]} scale={[0.95, 0.12, 0.5]}>
        <dodecahedronGeometry args={[1, 0]} />
        <meshStandardMaterial color="#6d9c80" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[2.95, 0.025, -3.55]} scale={[1.25, 0.12, 0.55]}>
        <dodecahedronGeometry args={[1, 0]} />
        <meshStandardMaterial color="#5b947e" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[-4.7, -2.2, -1.8]} rotation={[0.15, 0.35, 0.1]} scale={[1.45, 0.9, 1.05]}>
        <dodecahedronGeometry args={[1.45, 0]} />
        <meshStandardMaterial color="#363752" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[4.25, -2.35, 0.5]} rotation={[0.2, -0.5, 0.1]} scale={[1.55, 1, 1.15]}>
        <dodecahedronGeometry args={[1.5, 0]} />
        <meshStandardMaterial color="#41405f" roughness={0.92} flatShading />
      </mesh>
      <mesh position={[-1.8, -2.42, 2.55]} rotation={[0.2, 0.2, 0]} scale={[1.25, 0.85, 0.8]}>
        <dodecahedronGeometry args={[1.3, 0]} />
        <meshStandardMaterial color="#3a3a57" roughness={0.94} flatShading />
      </mesh>
    </group>
  );
}

function PineTree({ position, scale = 1, color = '#2f806c' }) {
  return (
    <group position={position} scale={scale}>
      <mesh position={[0, 0.31, 0]} castShadow>
        <cylinderGeometry args={[0.055, 0.1, 0.62, 7]} />
        <meshStandardMaterial color="#79513c" roughness={0.94} />
      </mesh>
      {[0.49, 0.78, 1.04].map((height, index) => (
        <mesh key={height} position={[0, height, 0]} castShadow>
          <coneGeometry args={[0.45 - index * 0.1, 0.72, 7]} />
          <meshStandardMaterial color={index === 0 ? '#286d5b' : color} roughness={0.9} flatShading />
        </mesh>
      ))}
    </group>
  );
}

function Waterfall({ position, rotation = 0, height = 2.8 }) {
  const material = useRef(null);
  useFrame(({ clock }) => {
    if (material.current) material.current.opacity = 0.57 + Math.sin(clock.elapsedTime * 2.4 + position[0]) * 0.08;
  });

  return (
    <group position={position} rotation={[0, rotation, 0]}>
      <mesh>
        <planeGeometry args={[0.64, height, 1, 1]} />
        <meshStandardMaterial ref={material} color="#66e5e9" emissive="#29aee0" emissiveIntensity={0.6} transparent opacity={0.62} side={2} depthWrite={false} />
      </mesh>
      <mesh position={[0, -height * 0.49, 0.035]}>
        <torusGeometry args={[0.35, 0.035, 5, 16]} />
        <meshStandardMaterial color="#a2ffff" emissive="#49d9f0" emissiveIntensity={1.1} transparent opacity={0.74} />
      </mesh>
    </group>
  );
}

function FloatingIsland({ position, scale = 1, delay = 0 }) {
  return (
    <Float speed={1.1} rotationIntensity={0.08} floatIntensity={0.28} floatingRange={[-0.17, 0.17]}>
      <group position={position} scale={scale} rotation={[0.08, delay, 0.12]}>
        <mesh position={[0, 0, 0]} castShadow>
          <cylinderGeometry args={[1.12, 1.36, 0.38, 7, 1]} />
          <meshStandardMaterial color="#588f7d" roughness={0.86} flatShading />
        </mesh>
        <mesh position={[0, -0.52, 0]} rotation={[Math.PI, 0, 0]} castShadow>
          <coneGeometry args={[1.25, 0.95, 7]} />
          <meshStandardMaterial color="#4a4569" roughness={0.9} flatShading />
        </mesh>
        <mesh position={[0.05, -0.8, 0.05]} scale={[0.56, 0.62, 0.55]} rotation={[0.18, 0.3, 0.08]} castShadow>
          <dodecahedronGeometry args={[0.8, 0]} />
          <meshStandardMaterial color="#383754" roughness={0.9} flatShading />
        </mesh>
        <mesh position={[0, -0.19, 0]}>
          <torusGeometry args={[1.13, 0.025, 5, 20]} />
          <meshStandardMaterial color="#72e5dc" emissive="#50d9ee" emissiveIntensity={0.75} />
        </mesh>
      </group>
    </Float>
  );
}

function Cloud({ position, scale = 1, phase = 0 }) {
  const cloudRef = useRef(null);
  useFrame(({ clock }) => {
    if (!cloudRef.current) return;
    cloudRef.current.position.x = position[0] + Math.sin(clock.elapsedTime * 0.16 + phase) * 0.34;
  });

  return (
    <group ref={cloudRef} position={position} scale={scale}>
      {[
        [-0.8, 0, 0, 0.72],
        [0, 0.16, 0, 1],
        [0.73, 0, 0.03, 0.68],
        [0.08, -0.12, 0.16, 0.76],
      ].map(([x, y, z, size], index) => (
        <mesh key={index} position={[x, y, z]} scale={[size, size * 0.56, size * 0.64]}>
        <sphereGeometry args={[1, 14, 10]} />
          <meshStandardMaterial color="#edf6ff" roughness={1} transparent opacity={0.82} />
        </mesh>
      ))}
    </group>
  );
}

function BuildingModel({ building }) {
  const glow = building.color;
  const base = <mesh position={[0, 0.12, 0]} castShadow receiveShadow><cylinderGeometry args={[0.67, 0.8, 0.24, 8]} /><meshStandardMaterial color="#424865" metalness={0.35} roughness={0.5} /></mesh>;
  const litRing = (radius, y, rotation = [Math.PI / 2, 0, 0]) => (
    <mesh position={[0, y, 0]} rotation={rotation}>
      <torusGeometry args={[radius, 0.035, 6, 24]} />
      <meshStandardMaterial color={glow} emissive={glow} emissiveIntensity={0.6} metalness={0.3} roughness={0.28} />
    </mesh>
  );

  switch (building.model) {
    case 'computer':
      return <group>{base}
        <mesh position={[0, 0.84, 0]} castShadow><boxGeometry args={[1.05, 1.18, 0.9]} /><meshStandardMaterial color="#435989" metalness={0.42} roughness={0.35} /></mesh>
        <mesh position={[0, 0.88, 0.47]}><planeGeometry args={[0.67, 0.69]} /><meshStandardMaterial color="#55dbe8" emissive="#249cdd" emissiveIntensity={0.85} /></mesh>
        <mesh position={[0, 1.5, 0]} castShadow><coneGeometry args={[0.72, 0.35, 6]} /><meshStandardMaterial color="#8292c8" metalness={0.48} roughness={0.38} /></mesh>
        {litRing(0.76, 0.25)}
        <mesh position={[0, 1.83, 0]}><sphereGeometry args={[0.11, 8, 6]} /><meshStandardMaterial color={glow} emissive={glow} emissiveIntensity={1.5} /></mesh>
      </group>;
    case 'algorithm':
      return <group>{base}
        <mesh position={[0, 0.83, 0]} castShadow><cylinderGeometry args={[0.49, 0.72, 1.2, 6]} /><meshStandardMaterial color="#4c477e" metalness={0.45} roughness={0.34} /></mesh>
        <mesh position={[0, 1.63, 0]} castShadow><coneGeometry args={[0.58, 0.58, 6]} /><meshStandardMaterial color="#9385dc" metalness={0.4} roughness={0.28} /></mesh>
        {litRing(0.61, 0.46)}{litRing(0.43, 1.05)}
        <mesh position={[0, 2, 0]}><sphereGeometry args={[0.1, 8, 6]} /><meshStandardMaterial color="#e2cdff" emissive={glow} emissiveIntensity={1.6} /></mesh>
      </group>;
    case 'python':
      return <group>{base}
        <mesh position={[0, 0.56, 0]} castShadow><cylinderGeometry args={[0.72, 0.77, 0.78, 10]} /><meshStandardMaterial color="#376d69" metalness={0.35} roughness={0.34} /></mesh>
        <mesh position={[0, 1.13, 0]} scale={[0.7, 0.65, 0.7]} castShadow><sphereGeometry args={[0.76, 12, 8]} /><meshStandardMaterial color="#7ec9c0" metalness={0.28} roughness={0.22} transparent opacity={0.88} /></mesh>
        {litRing(0.8, 0.25)}
        <mesh position={[0, 1.76, 0]}><sphereGeometry args={[0.09, 8, 6]} /><meshStandardMaterial color="#b9ffd7" emissive="#55e6a7" emissiveIntensity={1.3} /></mesh>
      </group>;
    case 'network':
      return <group>{base}
        <mesh position={[0, 0.92, 0]} castShadow><icosahedronGeometry args={[0.59, 1]} /><meshStandardMaterial color="#4568a7" metalness={0.48} roughness={0.22} wireframe /></mesh>
        <mesh position={[0, 0.92, 0]}><sphereGeometry args={[0.19, 10, 8]} /><meshStandardMaterial color="#94eaff" emissive="#328dff" emissiveIntensity={1.25} /></mesh>
        {litRing(0.76, 0.91, [0.3, 0.6, 0.1])}{litRing(0.7, 0.92, [1.1, 0.4, 0.25])}
        {[[0.75, 0.95, 0], [-0.72, 0.75, 0.14], [0.12, 1.4, 0.57]].map((position, index) => <mesh key={index} position={position}><sphereGeometry args={[0.1, 8, 6]} /><meshStandardMaterial color="#b4dfff" emissive={glow} emissiveIntensity={1} /></mesh>)}
      </group>;
    case 'security':
      return <group>{base}
        <mesh position={[0, 0.95, 0]} castShadow><octahedronGeometry args={[0.78, 0]} /><meshStandardMaterial color="#734d86" metalness={0.42} roughness={0.25} /></mesh>
        <mesh position={[0, 0.95, 0.56]}><circleGeometry args={[0.18, 8]} /><meshStandardMaterial color="#ffb6e8" emissive="#ea71cc" emissiveIntensity={0.9} /></mesh>
        {litRing(0.86, 0.33)}
        <mesh position={[0, 1.92, 0]}><sphereGeometry args={[0.1, 8, 6]} /><meshStandardMaterial color="#ffd4f2" emissive={glow} emissiveIntensity={1.4} /></mesh>
      </group>;
    case 'ai':
      return <group>{base}
        <mesh position={[0, 0.83, 0]} castShadow><sphereGeometry args={[0.62, 12, 9]} /><meshStandardMaterial color="#654b96" metalness={0.5} roughness={0.22} /></mesh>
        <mesh position={[0, 0.83, 0]}><sphereGeometry args={[0.34, 10, 8]} /><meshStandardMaterial color="#c5a4ff" emissive="#9668ff" emissiveIntensity={0.9} /></mesh>
        {litRing(0.85, 0.86, [1.05, 0.4, 0.2])}{litRing(0.72, 0.86, [0.35, 0.8, 0.4])}
        <mesh position={[0, 1.62, 0]}><sphereGeometry args={[0.11, 8, 6]} /><meshStandardMaterial color="#f0d4ff" emissive={glow} emissiveIntensity={1.4} /></mesh>
      </group>;
    default:
      return null;
  }
}

function InteractiveBuilding({ building, selected, onSelect }) {
  const group = useRef(null);
  const [hovered, setHovered] = useState(false);
  const { gl } = useThree();
  const desiredScale = useRef(new Vector3(1, 1, 1));

  useFrame((_, delta) => {
    if (!group.current) return;
    const scale = hovered || selected ? 1.07 : 1;
    group.current.scale.lerp(desiredScale.current.setScalar(scale), 1 - Math.exp(-10 * delta));
  });

  return (
    <group
      ref={group}
      position={[building.position[0], building.position[1] + 0.045, building.position[2]]}
      onClick={(event) => { event.stopPropagation(); onSelect(building); }}
      onPointerOver={(event) => { event.stopPropagation(); setHovered(true); gl.domElement.style.cursor = 'pointer'; }}
      onPointerOut={() => { setHovered(false); gl.domElement.style.cursor = 'auto'; }}
    >
      <BuildingModel building={building} />
      <pointLight position={[0, 1.6, 0]} color={building.color} intensity={selected ? 0.8 : 0.3} distance={3.6} />
      <Html position={[0, 2.25, 0]} center distanceFactor={13} style={{ pointerEvents: 'none' }}>
        <div className={`island-building-label${selected ? ' is-selected' : ''}`}>{building.shortTitle}</div>
      </Html>
    </group>
  );
}

function CameraFocus({ controlsRef, selectedBuilding }) {
  const { camera } = useThree();
  const target = useRef(new Vector3());
  const cameraPosition = useRef(new Vector3());
  const lookDirection = useRef(new Vector3(0.58, 0.48, 0.66).normalize());

  useFrame((_, delta) => {
    const controls = controlsRef.current;
    if (!controls) return;

    const easing = 1 - Math.exp(-delta * 1.8);
    if (selectedBuilding) {
      target.current.set(...selectedBuilding.position).y += 0.75;
      cameraPosition.current.copy(target.current).addScaledVector(lookDirection.current, 8.1);
    } else {
      target.current.set(0, 0.1, 0);
      cameraPosition.current.set(12, 10, 15);
    }

    controls.target.lerp(target.current, easing);
    camera.position.lerp(cameraPosition.current, easing);
    controls.update();
  });

  return null;
}

export default function IslandScene({ selectedBuilding, onSelect }) {
  const controlsRef = useRef(null);

  return (
    <>
      <color attach="background" args={['#6db5ef']} />
      <fog attach="fog" args={['#a8d7f0', 29, 72]} />
      <IslandSky />
      <hemisphereLight args={['#d8f1ff', '#51684b', 1.05]} />
      <ambientLight intensity={0.62} color="#dae8ff" />
      <directionalLight position={[-7, 12, 7]} intensity={2.45} color="#fff0d6" castShadow shadow-mapSize-width={1536} shadow-mapSize-height={1536} shadow-camera-left={-12} shadow-camera-right={12} shadow-camera-top={12} shadow-camera-bottom={-12} shadow-bias={-0.0002} />
      <pointLight position={[6, 4, -4]} intensity={1.3} color="#62c8ff" distance={30} />
      <pointLight position={[-5, 2, 5]} intensity={0.9} color="#a775ff" distance={23} />
      <Sparkles count={26} scale={[20, 12, 20]} size={1.6} speed={0.12} opacity={0.22} color="#fff2cf" />

      <group>
        <MainIsland />
        <ContactShadows position={[0, 0.035, 0]} scale={14} blur={2} far={4} opacity={0.25} resolution={256} color="#101729" />
        <IslandPath />
        <TerrainDetails />
        <PineTree position={[-5.25, 0.04, -0.65]} scale={0.8} />
        <PineTree position={[-5.1, 0.04, 1.5]} scale={0.68} color="#39836a" />
        <PineTree position={[-3.85, 0.04, 3.35]} scale={0.86} color="#337560" />
        <PineTree position={[-1.65, 0.04, -4.02]} scale={0.72} />
        <PineTree position={[1.85, 0.04, -4.03]} scale={0.82} color="#39836a" />
        <PineTree position={[5.05, 0.04, -1.45]} scale={0.76} />
        <PineTree position={[5.05, 0.04, 2.05]} scale={0.84} color="#39836a" />
        <PineTree position={[1.6, 0.04, 3.95]} scale={0.7} />
        <Waterfall position={[-3.8, -1.55, 3.5]} rotation={0.16} height={3.7} />
        <Waterfall position={[3.25, -1.45, 3.35]} rotation={-0.28} height={3.35} />
        <Waterfall position={[5.45, -1.2, -0.5]} rotation={1.08} height={2.9} />
        {buildings.map((building) => (
          <InteractiveBuilding key={building.id} building={building} selected={selectedBuilding?.id === building.id} onSelect={onSelect} />
        ))}
      </group>

      <FloatingIsland position={[-8.5, 4.6, -5.4]} scale={0.8} delay={0.4} />
      <FloatingIsland position={[8.7, 5.4, -6.1]} scale={0.65} delay={-0.8} />
      <FloatingIsland position={[8.8, 3.5, 5.8]} scale={0.55} delay={0.9} />
      <Cloud position={[-8.3, 2.7, 0.8]} scale={1.05} phase={0.4} />
      <Cloud position={[8.4, 3.2, 2.5]} scale={0.96} phase={1.5} />
      <Cloud position={[-3.7, 4.2, -8.3]} scale={0.85} phase={2.4} />
      <Cloud position={[3.4, 3.3, 8.1]} scale={0.9} phase={3.1} />
      <CameraFocus controlsRef={controlsRef} selectedBuilding={selectedBuilding} />
      <OrbitControls
        ref={controlsRef}
        makeDefault
        target={[0, 0.1, 0]}
        enablePan={false}
        enableDamping
        dampingFactor={0.075}
        rotateSpeed={0.58}
        zoomSpeed={0.7}
        minDistance={10}
        maxDistance={31}
        minPolarAngle={0.22}
        maxPolarAngle={Math.PI * 0.49}
      />
      <AdaptiveDpr pixelated />
    </>
  );
}


