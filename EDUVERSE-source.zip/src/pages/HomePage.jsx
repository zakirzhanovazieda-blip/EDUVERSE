import { ArrowUpRight, Compass, Sparkles } from 'lucide-react';
import CoursePreview from '../components/courses/CoursePreview.jsx';
import HeroSection from '../components/hero/HeroSection.jsx';

export default function HomePage() {
  return (
    <main id="main" tabIndex="-1">
      <HeroSection />
      <div className="feature-strip" id="about">
        <div className="feature-lead"><span className="feature-icon"><Compass size={19} aria-hidden="true" /></span><div><strong>Әр сабақ — жаңа зерттеу</strong><span>Көріп қана қоймай, өзің тәжірибе жасап үйрен.</span></div></div>
        <div className="feature-stat"><strong>6</strong><span>таным әлемі</span></div>
        <div className="feature-stat"><strong>∞</strong><span>жаңа мүмкіндік</span></div>
        <a href="#courses" className="feature-link">Біздің тәсіл <ArrowUpRight size={16} aria-hidden="true" /></a>
      </div>
      <CoursePreview />
      <section className="closing-note"><Sparkles size={17} aria-hidden="true" /><p>Болашаққа бастар жол бүгінгі қызығушылықтан басталады.</p><a href="#home">EDUVERSE-пен бірге баста</a></section>
    </main>
  );
}
