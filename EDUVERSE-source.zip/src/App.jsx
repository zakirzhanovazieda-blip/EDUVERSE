import { MotionConfig } from 'framer-motion';
import BrandHeader from './components/layout/BrandHeader.jsx';
import HomePage from './pages/HomePage.jsx';
import './styles.css';

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <div className="page-shell">
        <a className="skip-link" href="#main">Негізгі мазмұнға өту</a>
        <BrandHeader />
        <HomePage />
        <footer className="site-footer"><a className="footer-brand" href="#home">EDUVERSE</a><span>ҮЙРЕН · ЗЕРТТЕ · ТӘЖІРИБЕ ЖАСА</span><span>© EDUVERSE</span></footer>
      </div>
    </MotionConfig>
  );
}
