import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      output: {
        manualChunks(id) {
          const modulePath = id.replaceAll('\\', '/');
          if (modulePath.includes('/three/build/')) return 'three-vendor';
          if (modulePath.includes('/@react-three/fiber/')) return 'r3f-vendor';
          if (modulePath.includes('/@react-three/drei/')) return 'drei-vendor';
        },
      },
    },
  },
});

