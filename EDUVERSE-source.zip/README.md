# EDUVERSE

Қазақ тіліндегі интерактивті информатика платформасы. Басты бетте R3F негізіндегі 3D виртуалды арал орналасқан.

## Іске қосу

Node.js 20.19+ немесе 22.12+ және pnpm орнатыңыз. Жоба бумасында:

```bash
pnpm install
pnpm dev
```

Өндірістік жинақ құрып, алдын ала көру:

```bash
pnpm build
pnpm preview
```

Ғимараттар каталогының тексерістері:

```bash
pnpm test
```

## Құрылым

- `src/components/layout/` — ортақ орналасу компоненттері.
- `src/components/hero/` — басты экран.
- `src/components/virtual-world/` — Three.js сахнасы, камера, ғимараттар және басқару элементтері.
- `src/components/courses/` — курс карточкалары.
- `src/features/virtual-world/` — оқу ғимараттарының деректері мен тексерістері.
- `src/styles.css` — интерфейс стилі және бейімделетін 3D панелі.
- `vite.config.js` — React және 3D тәуелділіктері үшін өндірістік chunk баптауы.

Оқу аймақтары: Computer World, Algorithm City, Python Laboratory, Network World, Cyber Security және AI Laboratory. Негізгі арал мен ғимараттар procedural low-poly геометриясымен жасалған; сыртқы 3D модель не текстура қажет емес.

