# EDUVERSE Learning and Gameplay Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn the existing island into the start of an account-backed learning game with one complete Computer World lesson, accessible interactive activities, server-verified rewards, and persistent progress.

**Architecture:** Extend the API and database from the reviewed server/accounts plan. Keep lesson content versioned as validated JSON modules in the repository and seed it through the same migrations/seed runner for both PGlite and PostgreSQL. Server services authorize unlocks, grade a fixed set of deterministic activity types, and transactionally record idempotent attempts and recalculate XP, badges, and progress. Client feature modules render accessible lesson steps and read progress from the API; the current R3F island continues to display building availability and resume state.

**Tech Stack:** React/Vite/JavaScript ESM, Express 5, PGlite and `pg`, Zod, Node `node:test` and `supertest`, Vitest and Testing Library, existing R3F/Drei/Framer Motion/Lucide.

**Spec:** `docs/superpowers/specs/2026-11-05-eduverse-platform-design.md`; delivery sequence: `docs/superpowers/plans/2026-11-05-eduverse-platform-roadmap.md`; prerequisite API/auth interfaces: `docs/superpowers/plans/2026-11-05-eduverse-server-accounts-plan.md`.

## Global Constraints

- Complete this plan only after the server/accounts plan establishes the database, auth, class membership, and API conventions.
- Keep all lesson instructions, feedback, controls, progress labels, and accessibility labels in Kazakh.
- Do not trust client-supplied score, XP, badge, lesson completion, unlocked world, or user ID.
- Grade only the supported activity types with deterministic server-side rules; never execute student Python or arbitrary code.
- Persist attempts/progress/rewards on the authenticated user, and enforce lesson prerequisites on the server.
- Repeated `idempotencyKey` submissions return the original result and never award duplicate XP.
- Keep current homepage and 3D island available; provide a keyboard-accessible HTML world/lesson route independent of WebGL.
- Support narrow phone layouts, reduced motion, loading/error/retry states, and WebGL failure fallback.

## Review Focus

- **Forged or malformed answer payloads:** schema rejects invalid answer shapes and unknown activity IDs; test validation and unauthorized lesson access.
- **Duplicate and concurrent submissions:** same idempotency key has one canonical result/award under concurrent requests; test duplicate and racing requests.
- **Progress truth:** client cannot choose correct status/XP/unlocks; test wrong answers, partial completion, refresh, and next-device API read.
- **Content drift:** route IDs and JSON schemas reject missing worlds, duplicate IDs, invalid answer references, and unsupported activity types; test content catalog at startup/build.
- **Interaction accessibility/fallbacks:** keyboard-only tasks, reduced motion, phone widths, and unavailable WebGL keep lesson content usable; cover component behavior and inspect browser runtime.

---

### Task 1: Versioned content model and catalog API

**Files:**
- Create: `server/content/schema.js`, `server/content/catalog.js`, `server/content/worlds/computer-world.json`, `server/modules/lessons/lessons.routes.js`, `server/modules/lessons/lessons.repository.js`, `server/modules/lessons/lessons.service.js`, `server/tests/content-catalog.test.js`, `server/tests/lessons.test.js`
- Modify: `server/db/migrations/0001_accounts_and_classes.sql`, `server/app.js`, `server/config/env.js`

**Interfaces:**
- A lesson JSON record is `{ id, worldId, version, title, summary, level, estimatedMinutes, prerequisites, steps }`.
- Each step has `{ id, kind: 'explanation'|'activity', title, body?, activityId? }`; activity has `{ id, type, prompt, instructions?, options?, items?, answerKey, explanation, xp }`.
- Supported activity types: `multiple-choice` answer `{ optionId }`; `ordering` answer `{ itemIds: string[] }`; `binary-puzzle` answer `{ bits: string }`.
- `GET /api/v1/worlds` returns `{ worlds: [{ id, title, buildingId, status, completedLessons, totalLessons }] }` based on authenticated user's server progress.
- `GET /api/v1/lessons/catalog` requires teacher role and returns only published lesson summaries `{ lessons: [{ id, worldId, title, level, estimatedMinutes, version }] }` without activity keys.
- `GET /api/v1/worlds/:worldId/lessons/:lessonId` returns learner-facing lesson content without answer keys and returns `403` if prerequisites are not met.

- [ ] **Step 1: Write failing catalog schema and API tests**

Test every JSON file parses and validates; all world/building/lesson/activity IDs are unique; route only returns public fields; answer keys never appear; locked lesson rejects access; unauthenticated request fails.

- [ ] **Step 2: Run focused tests and verify failure**

Run: `pnpm exec node --test server/tests/content-catalog.test.js server/tests/lessons.test.js`
Expected: FAIL because lesson catalog and routes do not exist.

- [ ] **Step 3: Define Zod content schema and canonical six-world catalog**

Map world IDs to the existing building IDs from `src/features/virtual-world/buildings.js`. Seed all six world metadata records, with lesson content initially only in Computer World. Mark Computer World open and other worlds as locked by curriculum requirements; allow later lesson prerequisites without changing API response shape.

- [ ] **Step 4: Author the beginner Computer World lesson and persist seed content**

Write a Kazakh introduction to computer components with at least one explanation step and three activities covering multiple choice, ordering, and binary puzzle. Include clear explanation feedback, one retry/hint path, and lesson completion threshold requiring all activities to be correct.

- [ ] **Step 5: Implement catalog seeding, lesson read service, and routes**

Validate catalog at startup and seed idempotently by `(world_id, lesson_id, version)`. Strip `answerKey` before any API serialization. Require auth, enforce world/lesson/prerequisite existence, and return consistent Kazakh errors.

- [ ] **Step 6: Run catalog/lesson/API tests**

Run: `pnpm exec node --test server/tests/content-catalog.test.js server/tests/lessons.test.js server/tests/auth.test.js server/tests/db.test.js`
Expected: PASS for malformed content rejection, answer-key privacy, and unauthorized/locked access.

---

### Task 2: Deterministic scoring, idempotent attempts, and rewards

**Files:**
- Create: `server/modules/progress/scoring.js`, `server/modules/progress/progress.repository.js`, `server/modules/progress/progress.service.js`, `server/modules/progress/progress.routes.js`, `server/tests/scoring.test.js`, `server/tests/progress.test.js`
- Modify: `server/db/migrations/0001_accounts_and_classes.sql`, `server/app.js`, `server/modules/lessons/lessons.service.js`

**Interfaces:**
- `scoreActivity(activity, answer) -> { correct: boolean, normalizedAnswer, explanation, earnedXp }`; earned XP is activity XP for correct responses and `0` otherwise; no negative XP.
- `POST /api/v1/lessons/:lessonId/attempts` accepts `{ activityId, answer, idempotencyKey }` where key is 16–128 URL-safe characters.
- Response is `{ attempt: { id, activityId, correct, explanation, earnedXp, completedAt }, progress: { lessonCompleted, xpTotal, completedActivities, totalActivities, nextLessonId }, rewards: [{ id, title }] }`.
- `GET /api/v1/progress/me` returns authenticated user's XP, completed lesson IDs, rewards, and latest activity timestamp.

- [ ] **Step 1: Write failing scoring and progress service tests**

Cover exact/incorrect answers for each activity type, malformed answer rejection, answer-key normalization, lesson threshold, XP calculation on server, badge criteria, and cross-user isolation.

- [ ] **Step 2: Write failing API idempotency/concurrency tests**

Submit same key twice and in parallel; assert one attempt and one reward, identical canonical response. Submit different key and same answer; assert policy in the spec is explicit: each accepted activity counts once per learner/activity/version, while retries cannot farm XP.

- [ ] **Step 3: Run scoring/progress tests and verify failure**

Run: `pnpm exec node --test server/tests/scoring.test.js server/tests/progress.test.js`
Expected: FAIL because scoring and progress modules/tables do not exist.

- [ ] **Step 4: Implement pure scorer and transactional progress service**

Normalize only defined answer types and compare with server-held answer keys. Add unique constraints for `(user_id, lesson_id, activity_id, lesson_version)` and `(user_id, idempotency_key)`. In one DB transaction, persist attempt, calculate lesson completion and cumulative XP from canonical attempts, grant eligible rewards with a unique constraint, and advance unlock state.

- [ ] **Step 5: Add attempt/progress endpoints and ownership rules**

Use authenticated user ID from session only. Verify lesson and activity belong together and lesson is unlocked. Return replay-safe response on duplicate request; reject a key reused for a different payload with Kazakh `409`.

- [ ] **Step 6: Run scoring, progress, and database tests**

Run: `pnpm exec node --test server/tests/scoring.test.js server/tests/progress.test.js server/tests/lessons.test.js server/tests/db.test.js`
Expected: PASS; attempts/rewards persist after reopening PGlite and no duplicate XP is awarded.

---

### Task 3: Accessible lesson and activity experience

**Files:**
- Create: `src/features/lessons/lesson.api.js`, `src/features/lessons/LessonPage.jsx`, `src/features/lessons/ActivityRenderer.jsx`, `src/features/lessons/MultipleChoiceActivity.jsx`, `src/features/lessons/OrderingActivity.jsx`, `src/features/lessons/BinaryPuzzleActivity.jsx`, `src/features/lessons/lesson.test.jsx`
- Modify: `src/App.jsx`, `src/styles.css`, `src/services/api/client.js`

**Interfaces:**
- `lessonApi.getLesson(worldId, lessonId) -> Promise<LessonPublic>`; `lessonApi.submitAttempt(lessonId, payload) -> Promise<AttemptResult>`; `lessonApi.getProgress() -> Promise<ProgressSummary>`.
- Lesson route uses URL `/#/worlds/:worldId/lessons/:lessonId` or existing project router if one is added by the first plan; lesson IDs remain stable across refresh.
- Activity components receive `{ activity, onSubmit, disabled, result }` and emit only the typed learner answer, never score state.

- [ ] **Step 1: Write failing page/activity component tests**

Test lesson loading, activity type dispatch, keyboard selection/reordering, binary bit toggles, hint/explanation feedback, submitting/loading/error/retry states, completion summary, API timeout, and session expiry. Assert labels/help/error content in Kazakh and no answer key rendered.

- [ ] **Step 2: Run focused tests and verify failure**

Run: `pnpm exec vitest run src/features/lessons/lesson.test.jsx`
Expected: FAIL because lesson feature components do not exist.

- [ ] **Step 3: Implement API bindings and lesson state flow**

Use stable activity IDs and generate a fresh idempotency key per intentional submission; preserve key for network retry of the same payload. Do not optimistically award XP. Render server response as source of truth.

- [ ] **Step 4: Implement accessible activity components and progress feedback**

Use semantic forms, buttons, ordered lists, visible keyboard focus, status live regions, and touch targets. Ordering activity supports keyboard up/down controls as well as drag-independent controls. Respect reduced motion. Keep text lesson usable when WebGL is unavailable.

- [ ] **Step 5: Run component tests and client build**

Run: `pnpm exec vitest run src/features/lessons/lesson.test.jsx`
Run: `pnpm run build`
Expected: PASS with mobile-width layout and no runtime-only imports in lesson route.

---

### Task 4: Island-to-lesson flow and persistent resume state

**Files:**
- Create: `src/features/worlds/worlds.api.js`, `src/features/progress/ProgressSummary.jsx`, `src/features/progress/ResumeLearning.jsx`, `src/features/worlds/WorldDirectory.jsx`, `src/features/worlds/worlds.test.jsx`
- Create: `src/features/student-profile/StudentDashboard.jsx`, `src/features/student-profile/student-profile.test.jsx`
- Modify: `src/components/virtual-world/VirtualWorld.jsx`, `src/features/virtual-world/buildings.js`, `src/pages/HomePage.jsx`, `src/App.jsx`, `src/styles.css`

**Interfaces:**
- `worldsApi.list() -> Promise<WorldSummary[]>` reads availability/completion from `GET /api/v1/worlds`.
- `ProgressSummary` reads `/api/v1/progress/me` and shows server-derived XP, completed lessons, rewards, and recent activity.
- `StudentDashboard` composes the student's own profile summary, assignments from `/api/v1/assignments/me`, progress, and rewards without exposing other learners.
- Clicking Computer World opens its first available lesson; other buildings display the catalog status and a Kazakh explanation when locked/unreleased.
- `ResumeLearning` points to the earliest incomplete unlocked activity/lesson returned by the API.

- [ ] **Step 1: Write failing world-directory/island integration tests**

Test API state for six mapped buildings, Computer World navigation, locked-world messaging, signed-out CTA, progress loading/error state, resume route after completion, and fallback list when canvas/WebGL fails.

- [ ] **Step 2: Run focused tests and verify failure**

Run: `pnpm exec vitest run src/features/worlds/worlds.test.jsx`
Expected: FAIL because world/progress UI integration does not exist.

- [ ] **Step 3: Implement world/progress API modules and state-driven directory**

Use API status as source of truth. Never derive unlock or completed state from local storage; allow a non-sensitive last route hint only if the first plan's auth architecture approves it, but always revalidate it with the server.

- [ ] **Step 4: Wire island selection and HTML learning navigation**

Preserve existing building camera focus and information panel. Replace placeholder entry behavior with lesson navigation for available content; provide a visible accessible directory/resume card outside the canvas and a static fallback on WebGL error or low capability.

- [ ] **Step 5: Run full test/build/runtime verification for this phase**

Run: `pnpm test`
Run: `pnpm build`
Run: start server and Vite; register a student, complete the lesson, reload and verify XP/completion, then sign in on a second browser context and confirm server-restored progress.
Expected: all tests/build pass, one lesson is playable from island through completion, rewards remain unchanged on replay, and all six world cards match their building IDs.

## Following Plans

After this plan is reviewed and completed, create separate detailed plans for the teacher workspace, additional lesson content across the remaining five worlds, and production readiness. Python code execution requires its own sandbox design and security gate; block-based/order questions remain the supported Python introduction until then.
