# EDUVERSE Server and Accounts Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a tested Express API and persistent PGlite/PostgreSQL data layer, secure student and invited-teacher accounts, class membership, and a Kazakh client sign-in flow without disturbing the existing home page or 3D island.

**Architecture:** Keep the current Vite app at the repository root and add an ESM Express server under `server/`. Define one small async database interface (`query(text, params)`, `transaction(callback)`, `close()`) with PGlite and `pg` adapters, SQL migrations, and feature modules for auth and classes. Use server-side opaque sessions in hashed form with HttpOnly cookies; route handlers call services that validate inputs and enforce role/ownership rules. Add a client API helper and auth feature components, keeping presentation and server responsibilities separate.

**Tech Stack:** Existing React 19, Vite 7, JavaScript ESM, Node.js 24; Express 5, `@electric-sql/pglite`, `pg`, `argon2`, `zod`, `helmet`, `express-rate-limit`, `cookie`, `supertest`, Node `node:test`; existing Framer Motion and Lucide React.

**Spec:** `docs/superpowers/specs/2026-11-05-eduverse-platform-design.md`; phase outline: `docs/superpowers/plans/2026-11-05-eduverse-platform-roadmap.md`.

## Global Constraints

- Preserve the root React/Vite JavaScript application and its current home page and interactive island.
- Use Node.js 24 and Express 5; expose versioned routes under `/api/v1`.
- Use PGlite with persistent local files for development and PostgreSQL through `pg` for production, with the same SQL migrations.
- Keep passwords Argon2id-hashed and sessions server-side; set `HttpOnly`, `SameSite=Lax`, and `Secure` in production; do not put session tokens in `localStorage`.
- Restrict role registration: public registration creates students only; teachers require the configured invite secret or an admin-controlled process.
- Validate request bodies at the server boundary, rate-limit authentication, check request origin on mutations, and avoid returning stack traces.
- Do not collect email or legal names, commit secrets, run learner code, or trust client-supplied role/progress values.
- All visible user-facing copy is Kazakh; authentication remains usable on mobile and by keyboard.

## Review Focus

- **Database mode changes:** both PGlite and PostgreSQL adapters apply the same migrations and transaction semantics; test adapter contract and migration replay.
- **Session fixation and replay:** sign-in rotates/creates a fresh opaque token, only its hash is stored, logout revokes it, expired sessions fail; test each lifecycle transition.
- **Role escalation:** student payloads cannot request teacher/admin roles and teacher invite material is never echoed; test malformed, missing, and wrong invite cases.
- **Cross-class access:** a teacher cannot read or mutate another teacher's class or code; test a foreign class ID and stale/rotated join code.
- **Browser/API failure states:** unavailable server, invalid credentials, expired session, and narrow viewport show understandable Kazakh feedback and retain keyboard access; exercise through component/API integration coverage and production build.

---

### Task 1: Server foundation, database adapters, and migrations

**Files:**
- Modify: `package.json`, `vite.config.js`, `.gitignore`, `.env.example`
- Create: `server/index.js`, `server/app.js`, `server/config/env.js`, `server/config/database.js`
- Create: `server/db/index.js`, `server/db/pglite.js`, `server/db/postgres.js`, `server/db/migrate.js`, `server/db/migrations/0001_accounts_and_classes.sql`
- Create: `server/modules/health/health.routes.js`, `server/tests/db.test.js`, `server/tests/health.test.js`

**Interfaces:**
- `createDatabase(config) -> { query(text, params), transaction(callback), close() }`; `transaction` gives its callback an object with `query(text, params)` and commits/rolls back atomically.
- `createApp({ db, env }) -> Express app`; export without listening for integration tests.
- `runMigrations(db) -> Promise<void>` applies each numbered SQL migration once in lexical order and records its name in `schema_migrations`.
- `GET /api/v1/health -> 200 { status: "ok" }`; health output contains no secrets or database paths.

- [ ] **Step 1: Add failing database and health contract tests**

Test `createDatabase` against in-memory PGlite for parameter binding, rollback, migration idempotence, and persistence when reopening a temp data directory. Test health JSON/status from `createApp` using `supertest` without listening.

- [ ] **Step 2: Run the focused tests and verify they fail**

Run: `pnpm exec node --test server/tests/db.test.js server/tests/health.test.js`
Expected: FAIL because the server modules and database adapter do not exist.

- [ ] **Step 3: Install server dependencies and add scripts**

Add `express`, `@electric-sql/pglite`, `pg`, `argon2`, `zod`, `helmet`, `express-rate-limit`, `cookie`, and `supertest`; add `dev:server`, `start:server`, and `test:server` scripts. Preserve existing scripts and dependency set. Add Vite `/api` proxy to the local server port without changing current rendering.

- [ ] **Step 4: Implement env parsing, adapter contract, migration runner, app, and health route**

`DATABASE_MODE` accepts only `pglite` or `postgres`; local PGlite persists under ignored `server/.data/`. Production PostgreSQL uses `DATABASE_URL`. Fail fast on invalid/missing production configuration. Share SQL migration files across adapters. Add `.env.example` with placeholders only and ignore `.env*` except `.env.example`.

- [ ] **Step 5: Run focused server tests and existing island tests**

Run: `pnpm exec node --test server/tests/db.test.js server/tests/health.test.js src/features/virtual-world/buildings.test.mjs`
Expected: all tests pass; failed transactions leave no partial rows; repeated migrations do not duplicate schema state.

---

### Task 2: Student/teacher authentication and secure sessions

**Files:**
- Create: `server/modules/auth/auth.routes.js`, `server/modules/auth/auth.service.js`, `server/modules/auth/auth.repository.js`, `server/modules/auth/session.js`, `server/modules/auth/auth.validation.js`, `server/middleware/require-auth.js`, `server/tests/auth.test.js`
- Modify: `server/app.js`, `server/config/env.js`, `server/db/migrations/0001_accounts_and_classes.sql`, `.env.example`

**Interfaces:**
- `POST /api/v1/auth/register` accepts `{ username, displayName, password }` and creates a `student` only.
- `POST /api/v1/auth/teacher-invite` accepts `{ inviteCode, username, displayName, password }`; teacher creation requires constant-time comparison with configured invite secret, which is only allowed when explicitly configured.
- `POST /api/v1/auth/login` accepts `{ username, password }`; `GET /api/v1/auth/me` returns `{ user: { id, username, displayName, role } }`; `POST /api/v1/auth/logout` revokes the current session.
- `requireAuth(req, res, next)` loads a live session from the cookie and attaches only the public user record to `req.user`.
- Cookie name `eduverse_session`; token is 32 random bytes encoded base64url, only SHA-256 digest persisted; session expires after 14 days and rotates on successful login.

- [ ] **Step 1: Add failing auth integration tests**

Cover student registration/login/me/logout, duplicate username, bad password, malformed fields, wrong/missing teacher invite, cookie flags, hashed-only session persistence, expiry, and login token rotation. Assert every public error message is Kazakh and does not distinguish unknown username from bad password.

- [ ] **Step 2: Run auth tests and verify failure**

Run: `pnpm exec node --test server/tests/auth.test.js`
Expected: FAIL because the auth module, routes, and session table do not exist.

- [ ] **Step 3: Implement validation, password hashing, user repository, and session lifecycle**

Use Argon2id with explicit parameters; normalize usernames with a documented lowercase uniqueness policy while preserving display spelling. Generate tokens with `node:crypto`, store only the SHA-256 digest, set cookie `HttpOnly; SameSite=Lax; Path=/`, add `Secure` in production, and clear cookie on logout.

- [ ] **Step 4: Add auth middleware, routes, and rate limiting**

Apply a bounded `express-rate-limit` policy to login and registration. Require matching same-origin `Origin` for state-changing browser requests. Return a consistent Kazakh `401` error for invalid credentials, a `409` for duplicate username, and never expose hashes, invite values, or internal exceptions.

- [ ] **Step 5: Run auth integration tests plus all existing tests**

Run: `pnpm exec node --test server/tests/auth.test.js server/tests/db.test.js server/tests/health.test.js src/features/virtual-world/buildings.test.mjs`
Expected: PASS, session table stores only digests, logout/expiry makes the old cookie unusable.

---

### Task 3: Class creation, join codes, and ownership authorization

**Files:**
- Create: `server/modules/classes/classes.routes.js`, `server/modules/classes/classes.service.js`, `server/modules/classes/classes.repository.js`, `server/modules/classes/classes.validation.js`, `server/tests/classes.test.js`
- Modify: `server/app.js`, `server/db/migrations/0001_accounts_and_classes.sql`

**Interfaces:**
- `POST /api/v1/classes` requires teacher role and accepts `{ name }`; returns `{ class: { id, name, joinCode, createdAt } }`.
- `GET /api/v1/classes` returns classes the authenticated teacher owns or student belongs to, with role-appropriate fields.
- `POST /api/v1/classes/join` requires student role and accepts `{ joinCode }`; returns only the joined class's safe summary.
- `POST /api/v1/classes/:classId/join-code` requires the owning teacher, rotates the active join code, invalidates the old code, and returns the new code exactly once; only its digest is stored.
- Join code uses 8 uppercase unambiguous alphanumeric characters, stores a cryptographic digest, and is unique while active.
- `requireRole('teacher')` and class ownership checks live in server middleware/service, not UI conditions.

- [ ] **Step 1: Add failing class authorization and join tests**

Cover teacher class creation, student denial, valid/invalid code join, duplicate membership, hidden code from student list responses, owner-scoped listing, foreign teacher class access returning `404`, and join-code rotation invalidating the previous code.

- [ ] **Step 2: Run class tests and verify failure**

Run: `pnpm exec node --test server/tests/classes.test.js`
Expected: FAIL because class routes and tables are not implemented.

- [ ] **Step 3: Implement class schema and transactional service**

Add classes/memberships tables with foreign keys and uniqueness constraints. Generate code from `node:crypto`; persist only digest. Join operation must be atomic and idempotent for an existing membership.

- [ ] **Step 4: Add protected class routes and ownership checks**

Apply auth and role middleware before service calls; ensure list queries constrain owner/member IDs in SQL. Return localized validation and not-found messages without revealing other class records.

- [ ] **Step 5: Run class/auth/database tests together**

Run: `pnpm exec node --test server/tests/classes.test.js server/tests/auth.test.js server/tests/db.test.js server/tests/health.test.js`
Expected: PASS, including isolation between two teachers and two student accounts.

---

### Task 4: Kazakh client authentication and protected routing

**Files:**
- Create: `src/services/api/client.js`, `src/features/auth/AuthProvider.jsx`, `src/features/auth/auth.api.js`, `src/features/auth/LoginPage.jsx`, `src/features/auth/RegisterPage.jsx`, `src/features/auth/RequireAuth.jsx`, `src/features/auth/auth.test.jsx`
- Modify: `src/App.jsx`, `src/components/layout/BrandHeader.jsx`, `src/pages/HomePage.jsx`, `src/styles.css`, `package.json`
- Add test tooling only as dev dependencies: `vitest`, `jsdom`, `@testing-library/react`, `@testing-library/user-event`, `@testing-library/jest-dom`.

**Interfaces:**
- `apiRequest(path, options) -> Promise<JSON>` prefixes `/api/v1`, uses `credentials: 'include'`, sends JSON, and throws `ApiError { status, message }`.
- `AuthProvider` exposes `{ user, status, login, register, logout, refresh }`; status is `loading | authenticated | anonymous`.
- `RequireAuth` redirects anonymous users to `/?бет=кіру` or displays the login route; it never substitutes for API authorization.
- Home header shows `Кіру` to visitors and a public display name plus `Шығу` when signed in.

- [ ] **Step 1: Add failing API/auth component tests**

Test cookie credential mode and JSON errors; loading/anonymous/authenticated provider states; registration and login validation; logout; mobile-friendly labels; keyboard focus order; header reflects auth state; protected routes handle expired sessions in Kazakh.

- [ ] **Step 2: Run focused client tests and verify failure**

Run: `pnpm exec vitest run src/features/auth/auth.test.jsx`
Expected: FAIL because auth client components and Vitest configuration do not exist.

- [ ] **Step 3: Implement API client and AuthProvider**

Fetch `/api/v1/auth/me` on app start; use cookie-backed sessions only. Abort duplicate startup requests in StrictMode safely. Normalize API errors without replacing user input after a failed request.

- [ ] **Step 4: Implement Kazakh auth pages and route integration**

Add accessible login and student registration pages styled with the current dark blue/purple/cyan visual language. Add teacher invite as a separate form behind an explicit “Мұғалім шақыруы” path; do not show invite secrets to students. Keep current home and island navigation/rendering intact.

- [ ] **Step 5: Run client tests and full build**

Run: `pnpm exec vitest run src/features/auth/auth.test.jsx`
Run: `pnpm run build`
Run: `pnpm exec node --test server/tests/*.test.js src/features/virtual-world/buildings.test.mjs`
Expected: all tests/build pass; signed-out home and 3D scene still render and mobile form labels remain readable.

---

### Task 5: Developer runbook and end-to-end verification

**Files:**
- Modify: `README.md`, `.env.example`, `package.json`
- Create: `server/tests/auth-flow.test.js`

**Interfaces:**
- `pnpm dev` starts Vite and server together; Vite proxies `/api` to the server.
- `pnpm build` builds the client; `pnpm start:server` starts API with production environment validation.
- `pnpm test` runs existing island tests, client tests, and server integration tests.

- [ ] **Step 1: Add end-to-end auth flow test**

Use a temporary PGlite directory and a real HTTP listener to register, log in, load `/me`, create a class (teacher invite path), join as student, log out, restart the server against the same PGlite directory, and verify user/class records persist while revoked sessions do not work.

- [ ] **Step 2: Run flow test and verify failure**

Run: `pnpm exec node --test server/tests/auth-flow.test.js`
Expected: FAIL until the actual configured server start and persistence behavior are wired.

- [ ] **Step 3: Wire concurrent development script and test aggregator**

Use `concurrently` (dev dependency) for `pnpm dev`; ensure shutdown signals close Vite, Express, and PGlite cleanly. Keep `pnpm start:server` separate for deployment.

- [ ] **Step 4: Document local setup, safe credentials, and API behavior**

Document Node 24 prerequisite, `pnpm install`, `.env` copy, dev/test/build commands, PGlite data location, deleting local demo data, and teacher invitation setup. State that `.env` and `server/.data` must not be committed. Do not place a real teacher password or invite secret in docs.

- [ ] **Step 5: Run complete verification from a clean dependency install**

Run: `pnpm install --frozen-lockfile`
Run: `pnpm test`
Run: `pnpm build`
Run: start development services and verify `GET /api/v1/health` returns 200, then exercise the browser login/register flow on desktop and a narrow mobile viewport.
Expected: all checks pass; restarting server preserves accounts/classes; browser console has no runtime/import errors; existing island interactions remain available.

## Following Plans

After this plan is reviewed and completed, write separate detailed plans for the learning/gameplay vertical slice, teacher workspace, remaining learning worlds, and production readiness before implementing those subsystems. Maintain the same endpoint, database, authorization, localization, and test contracts from the approved design.
