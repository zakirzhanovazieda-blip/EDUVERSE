# EDUVERSE Teacher Workspace Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Give teachers a secure Kazakh-language workspace to manage their own classes and join codes, assign published lessons, and follow learner progress without exposing students' raw answers or other classes.

**Architecture:** Extend the server's class/auth/lesson/progress modules and keep authorization in server services/SQL. Teacher-facing endpoints return class-scoped summaries that aggregate server-verified progress and assignment status. The React workspace is a separate feature area with routes for class overview, roster/progress, and assignments; it uses the existing cookie-backed auth client and semantic responsive controls. No arbitrary lesson authoring is included.

**Tech Stack:** React/Vite/JavaScript ESM, Express 5, PGlite and `pg`, existing auth and lesson/progress APIs, Zod, Node `node:test`/`supertest`, Vitest, Testing Library, Framer Motion and Lucide React.

**Spec:** `docs/superpowers/specs/2026-11-05-eduverse-platform-design.md`; prerequisite: [server/accounts plan](2026-11-05-eduverse-server-accounts-plan.md), then [learning/gameplay plan](2026-11-05-eduverse-learning-gameplay-plan.md); delivery sequence: [roadmap](2026-11-05-eduverse-platform-roadmap.md).

## Global Constraints

- Do not start before account, class membership, lesson, and progress contracts from the prerequisite plans exist.
- Every teacher read/write is scoped by authenticated teacher ID and owned class ID in the server/database query.
- Students can never create assignments or read teacher-only summaries; other teachers cannot see a foreign class.
- Do not expose raw wrong answers, password/session data, join-code digests, or internal IDs without a product need.
- Join codes are shown only on creation/rotation response; only a digest is stored; rotation invalidates the old code.
- All visible interface copy is Kazakh, with mobile and keyboard support, loading/error/empty states, and no dependency on WebGL.
- Teachers choose only from published lessons; no HTML/SQL authoring or arbitrary code is permitted.

## Review Focus

- **Foreign class ID guessing:** all dashboard, member, assignment, and rotate-code routes return safe not-found for non-owned classes; test teacher A against teacher B's records.
- **Student data minimization:** roster shows necessary identity and aggregate progress only; tests assert no answer body/session/hash fields leak.
- **Join code lifecycle:** active code is digest-only, rotation invalidates old code atomically, and student responses never return it; test rotation race and old-code join.
- **Assignment edge cases:** no unpublished lesson, past/invalid deadline, or duplicate assignment silently creates inconsistent state; test validation and unique semantics.
- **Empty and stale class views:** empty roster, no assignments, learner leave/disable, and assignment completion changes produce understandable Kazakh status; test summary aggregation and UI states.

---

### Task 1: Assignment persistence and class-scoped API

**Files:**
- Create: `server/modules/teacher/teacher.routes.js`, `server/modules/teacher/teacher.service.js`, `server/modules/teacher/teacher.repository.js`, `server/modules/teacher/teacher.validation.js`, `server/tests/teacher-authorization.test.js`, `server/tests/assignments.test.js`
- Modify: `server/db/migrations/0001_accounts_and_classes.sql`, `server/app.js`, `server/modules/classes/classes.routes.js`, `server/modules/classes/classes.service.js`

**Interfaces:**
- `GET /api/v1/classes/:classId` requires the owning teacher and returns `{ class: { id, name, createdAt, memberCount } }`; it never returns the stored join-code digest.
- `POST /api/v1/classes/:classId/assignments` accepts `{ lessonId, dueAt? }` and returns `{ assignment: { id, lessonId, lessonTitle, dueAt, createdAt, status } }`.
- `GET /api/v1/classes/:classId/assignments` returns only assignments for an owned class with learner completion counts, not individual raw answers.
- `GET /api/v1/assignments/me` returns the authenticated student's assignments for their joined classes.
- `PATCH /api/v1/classes/:classId/assignments/:assignmentId` accepts `{ dueAt?, status? }`; status is `active|closed`; only the class owner may update.
- `GET /api/v1/classes/:classId/progress` returns `{ summary, students: [{ userId, displayName, username, xpTotal, completedLessons, assignmentStatus, lastActiveAt }] }` with no raw attempt answers.
- `GET /api/v1/lessons/catalog` (defined by the learning/gameplay plan) supplies published lesson options for the assignment form.

- [ ] **Step 1: Write failing assignment/authorization API tests**

Cover teacher ownership, student denial, cross-class ID access, published/open lesson validation, due date parsing/time zone, close/reopen, student own assignments, class-level counts, empty class, and absence of sensitive/raw-answer fields.

- [ ] **Step 2: Run focused API tests and verify they fail**

Run: `pnpm exec node --test server/tests/teacher-authorization.test.js server/tests/assignments.test.js`
Expected: FAIL because assignment tables/routes and teacher progress projection do not exist.

- [ ] **Step 3: Add assignment schema and service rules**

Use foreign keys to class and lesson, an index by class/status/due time, and transactionally validate lesson availability. Define one active assignment per `(class_id, lesson_id)`; reopening an existing closed assignment updates its status rather than creating a duplicate. Persist timestamps in UTC.

- [ ] **Step 4: Implement class-scoped teacher and student endpoints**

Make class ownership/member constraints part of repository SQL, not only a previous UI/middleware check. Student `assignments/me` filters through their memberships and returns only safe lesson metadata. Progress summary uses aggregate SQL and strips answer details.

- [ ] **Step 5: Run API authorization and aggregation tests**

Run: `pnpm exec node --test server/tests/teacher-authorization.test.js server/tests/assignments.test.js server/tests/classes.test.js server/tests/progress.test.js`
Expected: PASS for valid owners/members and reject/404 for all foreign identities.

---

### Task 2: Teacher class dashboard and roster

**Files:**
- Create: `src/features/teacher/teacher.api.js`, `src/features/teacher/TeacherLayout.jsx`, `src/features/teacher/TeacherHomePage.jsx`, `src/features/teacher/ClassDashboard.jsx`, `src/features/teacher/ClassRoster.jsx`, `src/features/teacher/JoinCodeCard.jsx`, `src/features/teacher/teacher.test.jsx`
- Modify: `src/App.jsx`, `src/components/layout/BrandHeader.jsx`, `src/styles.css`

**Interfaces:**
- `teacherApi.listClasses() -> Promise<ClassSummary[]>`; `teacherApi.getClass(classId) -> Promise<ClassDashboard>`; `teacherApi.getProgress(classId) -> Promise<ClassProgress>`.
- `teacherApi.rotateJoinCode(classId) -> Promise<{ joinCode, rotatedAt }>` receives one-time plaintext code and never persists it in app state beyond the explicit success panel.
- Teacher routes require `user.role === 'teacher'` for rendering, while server endpoints independently enforce role and ownership.
- Roster columns: display name, username, completed lesson count, total XP, assignment status, last active; sort and empty state localized in Kazakh.

- [ ] **Step 1: Write failing teacher dashboard tests**

Test teacher-only route, loading/no-class/class-empty states, class summary, roster data mapping, one-time code result dismissal, API failure and retry, no raw answer/session fields in UI, and responsive semantic table/list at phone width.

- [ ] **Step 2: Run focused tests and verify failure**

Run: `pnpm exec vitest run src/features/teacher/teacher.test.jsx`
Expected: FAIL because teacher workspace components do not exist.

- [ ] **Step 3: Implement typed API methods and dashboard layout**

Use the shared cookie API client and render server error messages in Kazakh. Do not store returned join code beyond the one-time confirmation view; do not write it to local storage or telemetry.

- [ ] **Step 4: Implement class list, dashboard, roster, and join-code controls**

Use real button/form semantics, table headers on desktop, stacked summary cards on mobile, focus indicators, and pagination or incremental loading for long rosters. Rotating a code requires a confirmation dialog stating that the old code stops working.

- [ ] **Step 5: Run UI tests and build**

Run: `pnpm exec vitest run src/features/teacher/teacher.test.jsx`
Run: `pnpm run build`
Expected: PASS; desktop and 360px layout retain all controls and the general existing brand visual language.

---

### Task 3: Assignment creation/editing and progress summaries

**Files:**
- Create: `src/features/teacher/AssignmentList.jsx`, `src/features/teacher/AssignmentForm.jsx`, `src/features/teacher/ClassProgressSummary.jsx`, `src/features/teacher/assignments.test.jsx`
- Modify: `src/features/teacher/teacher.api.js`, `src/features/teacher/ClassDashboard.jsx`, `src/styles.css`

**Interfaces:**
- `teacherApi.createAssignment(classId, { lessonId, dueAt? }) -> Promise<Assignment>`.
- `teacherApi.updateAssignment(classId, assignmentId, { dueAt?, status? }) -> Promise<Assignment>`.
- `teacherApi.listAssignments(classId) -> Promise<AssignmentSummary[]>` and `teacherApi.getPublishedLessons() -> Promise<PublishedLesson[]>`.
- Form due date is optional; if entered, serialize as ISO UTC and display in browser locale with an explicit Kazakh label.

- [ ] **Step 1: Write failing assignment UI tests**

Test available lesson selection, required lesson validation, optional due date, submit/duplicate prevention, server errors, close/reopen status, assignment completion counts, and empty assignment list.

- [ ] **Step 2: Run tests and verify failure**

Run: `pnpm exec vitest run src/features/teacher/assignments.test.jsx`
Expected: FAIL because assignment UI and methods are missing.

- [ ] **Step 3: Implement API methods and form state**

Load published lessons from server, parse date input to a valid ISO timestamp, block past deadlines only when policy allows (server validation remains authoritative), and keep accessible status feedback.

- [ ] **Step 4: Implement assignment list, status controls, and class summary**

Display learner aggregate completion counts and due/closed status. Avoid exposing which exact wrong answers students selected. Require clear confirmation before closing or reopening an assignment when the change affects learners.

- [ ] **Step 5: Run assignment UI tests and existing suite**

Run: `pnpm exec vitest run src/features/teacher/teacher.test.jsx src/features/teacher/assignments.test.jsx`
Run: `pnpm test`
Expected: PASS with focusable controls, no regressions in student learning routes, and no browser console errors.

---

### Task 4: Student assignment visibility and teacher end-to-end checks

**Files:**
- Create: `src/features/lessons/AssignmentNotice.jsx`, `server/tests/teacher-flow.test.js`
- Modify: `src/features/lessons/LessonPage.jsx`, `src/features/student-profile/StudentDashboard.jsx`, `README.md`

**Interfaces:**
- Student assignment list displays only assignments associated with the student's active class memberships.
- Lesson page shows due date and assignment completion status when opened from an assignment; independent lesson progress remains governed by the lesson rules.
- End-to-end workflow covers teacher invite, class creation, one-time code rotation, student join, assignment, student completion, teacher progress refresh, and old-code rejection.

- [ ] **Step 1: Write failing student assignment visibility and integration tests**

Cover a student in two classes, teacher-owned assignment, closed assignment visibility, no assignment leakage across classes, and aggregate completion updating only after canonical lesson completion.

- [ ] **Step 2: Run focused checks and verify failure**

Run: `pnpm exec node --test server/tests/teacher-flow.test.js`
Expected: FAIL until full workflow runs over the real app and persistent PGlite.

- [ ] **Step 3: Implement student assignment notice and dashboard link**

Use a clear Kazakh status label and accessible link to the lesson. Closed assignments remain visible with a closed label; they cannot be submitted as assignments while course practice may remain available if lesson policy permits.

- [ ] **Step 4: Add end-to-end class/assignment workflow and update runbook**

Test API and UI behavior against persistent PGlite, then document teacher invitation setup, class creation, one-time join code, assignment management, and data-minimization behavior.

- [ ] **Step 5: Run full suite and verify desktop/mobile teacher flow**

Run: `pnpm test`
Run: `pnpm build`
Run: teacher/student workflow through browser at desktop and 360px viewport.
Expected: all checks pass; teacher sees only owned classes and necessary aggregates; student sees their own assignments; existing 3D island and lesson flow remain usable.

## Following Plans

Write separate detailed plans for additional learning content in the five remaining worlds and for production readiness. Do not add real-time multiplayer or unrestricted content authoring under this workspace scope.
