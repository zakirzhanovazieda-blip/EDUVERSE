# EDUVERSE Platform Implementation Roadmap

**Goal:** Build EDUVERSE into a full Kazakh-language, account-backed, gamified informatics learning platform while preserving the existing React/Vite home page and 3D island.

**Approved design:** [Platform design](../specs/2026-11-05-eduverse-platform-design.md)

The approved design spans distinct subsystems, so implementation is split into independently reviewable plans. The first plan is [Server and accounts](2026-11-05-eduverse-server-accounts-plan.md). Create and review a concrete plan for each later subsystem before implementing that subsystem.

## Delivery sequence

1. **Server and accounts** — Express API, persistent local PGlite and production PostgreSQL adapters, SQL migrations, student sign-up/sign-in, invited teacher access, secure sessions, roles, class creation/join codes, and the client auth flow. See [server/accounts plan](2026-11-05-eduverse-server-accounts-plan.md).
2. **Learning and gameplay** — versioned lesson/activity content, a Computer World beginner lesson, accessible interactive tasks, authoritative server scoring, idempotent attempts, XP/rewards/progress, and island resume state. See [learning/gameplay plan](2026-11-05-eduverse-learning-gameplay-plan.md).
3. **Teacher workspace** — class roster and progress views, lesson assignments and due dates, class-scoped authorization, and privacy-conscious summaries. See [teacher workspace plan](2026-11-05-eduverse-teacher-workspace-plan.md).
4. **Six learning worlds** — Computer World, Algorithm City, Python Laboratory, Network World, Cyber Security, and AI Laboratory content using shared lesson/activity contracts.
5. **Production readiness** — PostgreSQL deployment configuration, HTTPS cookies, secrets, migrations, backups/restores, monitoring, retention and privacy policy, and deployment runbook. Hosting provider and domain remain undecided until this phase.
6. **Safe Python execution (separate decision and plan)** — only if a dedicated sandbox, resource/network restrictions, and security verification are available; never execute submitted code in the API process.

## Cross-cutting acceptance criteria

- All learner- and teacher-facing text is in Kazakh; layout and 3D fallbacks work on desktop and mobile.
- The existing home page and island remain available during auth and app routing changes.
- Client input is never authoritative for roles, progress, XP, rewards, class ownership, or lesson scores.
- Session identifiers are opaque, server-side, rotated at authentication, revoked on logout, and never stored in `localStorage`.
- Production secrets and real teacher credentials are not committed or seeded.
- Each phase ships with tests for its own behavior and build/runtime checks appropriate to that phase.
